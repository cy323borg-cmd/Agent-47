package com.agent47

import android.content.Context
import android.content.Intent
import androidx.work.Worker
import androidx.work.WorkerParameters

class CoreAgentWorker(val context: Context, params: WorkerParameters) : Worker(context, params) {
    override fun doWork(): Result {
        // পরবর্তী বার্স্ট (Burst) শুরু করার সিগন্যাল
        val intent = Intent(context, CoreAgentService::class.java)
        context.startService(intent)
        return Result.success()
    }
}
