package com.agent47

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

class MissionRestarter : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        // V12.7: Reboot বা Kill হলে অটো রিস্টার্ট লজিক
        if (intent.action == Intent.ACTION_BOOT_COMPLETED || intent.action == "RESTART_AGENT_47") {
            val serviceIntent = Intent(context, CoreAgentService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(serviceIntent)
            } else {
                context.startService(serviceIntent)
            }
        }
    }
}
